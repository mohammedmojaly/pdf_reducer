Option Strict On
Imports LoansPQBO.XPressLoans
Imports StdLib.DBUtils
Imports StdLib
Imports System.Data
Imports LoansPQBO.std
Imports LoansPQBO.EnumLibrary

Namespace DocMapper.Mappers

	Partial Class Local_Library_Class
		Inherits System.Web.UI.UserControl
	End Class

    Public Class GFELibrary_ECD
        Inherits CMapper

#Region "GFE Skeleton"
        Protected NewXMLContent As XElement = <GFE2015><LOAN_ESTIMATE></LOAN_ESTIMATE><CLOSING_DISCLOSURE/></GFE2015>

        Protected _XML As XElement = Nothing
        Protected ReadOnly Property oXML() As XElement

            Get
                If _XML Is Nothing Then
                    Dim sXml As String = SafeString(App.ToMortgageApp.AppInfo.GFE("GFE2015"))

                    If sXml = "" Then
                        _XML = NewXMLContent
                    Else
                        Try
                            _XML = XElement.Parse(sXml.Replace("xmlns", "x_xmlns"))

                        Catch ex As Exception
                            _XML = NewXMLContent
                        End Try
                    End If
                End If

                Return _XML
            End Get
        End Property

        Protected _SectionA As XElement = Nothing
        Protected ReadOnly Property SECTION_A() As XElement
            Get
                If _SectionA Is Nothing Then

                    Dim sectionA As XElement = oXML.Element(GFESection).Element("SECTION_A")
                    If sectionA Is Nothing Then
                        sectionA = <SECTION_A/>
                        oXML.Element(GFESection).Add(sectionA)
                    End If
                    If sectionA.Elements("ORIGINATION_CHARGE").Count = 0 Then
                        For counter As Integer = 1 To 6
                            sectionA.Add(<ORIGINATION_CHARGE/>)
                        Next
                    End If

                    _SectionA = sectionA
                End If

                Return _SectionA
            End Get
        End Property

        Protected _eSectionA As XElement = Nothing
        Protected ReadOnly Property E_SECTION_A() As XElement
            Get
                If _eSectionA Is Nothing Then

                    Dim eSectionA As XElement = oXML.Element(GFESection).Element("SECTION_A")
                    If eSectionA Is Nothing Then
                        eSectionA = <SECTION_A/>
                        oXML.Element(GFESection).Add(eSectionA)
                    End If
                    If eSectionA.Elements("ORIGINATION_CHARGE").Count = 0 Then
                        For counter As Integer = 1 To 6
                            eSectionA.Add(<ORIGINATION_CHARGE/>)
                        Next
                    End If

                    _eSectionA = eSectionA
                End If

                Return _eSectionA
            End Get
        End Property

        Protected _OriginationCharges As List(Of XElement) = Nothing
        Protected ReadOnly Property OriginationCharges() As List(Of XElement)
            Get
                If _OriginationCharges Is Nothing Then
					_OriginationCharges = (From x In SECTION_A.Elements("ORIGINATION_CHARGE")
										 Where SafeDouble(GetAttribute(x, "origination_charge_amount")) > 0 Select x).ToList
                    SortList(_OriginationCharges, "origination_charge_description", "FeeName")
                End If
                Return _OriginationCharges
            End Get
        End Property

        Protected _SectionB As XElement = Nothing
        Protected ReadOnly Property SECTION_B() As XElement
            Get
                If _SectionB Is Nothing Then

                    Dim sectionB As XElement = oXML.Element(GFESection).Element("SECTION_B")
                    If sectionB Is Nothing Then
                        sectionB = <SECTION_B/>
                        SECTION_A.AddAfterSelf(sectionB)
                    End If
                    If sectionB.Elements("SERVICE_ITEM").Count = 0 Then
                        For counter As Integer = 1 To 12
                            sectionB.Add(<SERVICE_ITEM></SERVICE_ITEM>)
                        Next
                    End If

                    _SectionB = sectionB
                End If

                Return _SectionB
            End Get
        End Property

        Protected _ServiceItemsCannotShop As List(Of XElement) = Nothing
        Protected ReadOnly Property ServiceItemsCannotShop() As List(Of XElement)
            Get
                If _ServiceItemsCannotShop Is Nothing Then
					_ServiceItemsCannotShop = (From x In SECTION_B.Elements("SERVICE_ITEM")
										 Where (GetAttribute(x, "service_tolerance_category") = "LRCS" Or
											GetAttribute(x, "service_tolerance_category") = "BCLPL") And
											SafeDouble(GetAttribute(x, "service_fee_amount")) > 0
										Select x).ToList
                        SortList(_ServiceItemsCannotShop, "service_fee_description", "FeeName")
				End If
				Return _ServiceItemsCannotShop
            End Get
        End Property

        Protected _ServiceItemsShop As List(Of XElement) = Nothing
        Protected ReadOnly Property ServiceItemsShop() As List(Of XElement)
            Get
                If _ServiceItemsShop Is Nothing Then
					_ServiceItemsShop = (From x In SECTION_B.Elements("SERVICE_ITEM")
										 Where (GetAttribute(x, "service_tolerance_category") = "BCOP" Or
											GetAttribute(x, "service_tolerance_category") = "BCNLR") And
											SafeDouble(GetAttribute(x, "service_fee_amount")) > 0
										Select x).ToList
                        SortList(_ServiceItemsShop, "service_fee_description", "FeeName")
				End If
				Return _ServiceItemsShop
            End Get
        End Property

        Protected _SectionC As XElement = Nothing
        Protected ReadOnly Property SECTION_C() As XElement
            Get
                If _SectionC Is Nothing Then

                    Dim sectionC As XElement = oXML.Element(GFESection).Element("SECTION_C")
                    If sectionC Is Nothing Then
                        sectionC = <SECTION_C/>
                        SECTION_B.AddAfterSelf(sectionC)
                    End If

                    _SectionC = sectionC
                End If

                Return _SectionC
            End Get
        End Property


        Protected _sectionD As XElement = Nothing
        Protected ReadOnly Property SECTION_D() As XElement
            Get
                If _sectionD Is Nothing Then

                    Dim sectionD As XElement = oXML.Element(GFESection).Element("SECTION_D")
                    If sectionD Is Nothing Then
                        sectionD = <SECTION_D/>
                        SECTION_C.AddAfterSelf(sectionD)
                    End If

                    _sectionD = sectionD
                End If

                Return _sectionD
            End Get
        End Property

        Protected _sectionE As XElement = Nothing
        Protected ReadOnly Property SECTION_E() As XElement
            Get
                If _sectionE Is Nothing Then

                    Dim sectionE As XElement = oXML.Element(GFESection).Element("SECTION_E")
                    If sectionE Is Nothing Then
                        sectionE = <SECTION_E/>
                        SECTION_D.AddAfterSelf(sectionE)
                    End If

                    If sectionE.Elements("OTHER_TAX_ITEM").Count = 0 Then
                        For counter As Integer = 1 To 2
                            sectionE.Add(<OTHER_TAX_ITEM/>)
                        Next
                    End If

                    _sectionE = sectionE
                End If

                Return _sectionE
            End Get
        End Property

        Protected _OtherTaxItem As List(Of XElement) = Nothing
        Protected ReadOnly Property OtherTaxItem() As List(Of XElement)
            Get
                If oXML IsNot Nothing AndAlso _OtherTaxItem Is Nothing Then
                    _OtherTaxItem = SECTION_E.Elements("OTHER_TAX_ITEM").ToList
                End If
                Return _OtherTaxItem
            End Get
        End Property

        Protected _sectionF As XElement = Nothing
        Protected ReadOnly Property SECTION_F() As XElement
            Get
                If _sectionF Is Nothing Then

                    Dim sectionF As XElement = oXML.Element(GFESection).Element("SECTION_F")
                    If sectionF Is Nothing Then
                        sectionF = <SECTION_F/>
                        SECTION_E.AddAfterSelf(sectionF)
                    End If

                    _sectionF = sectionF
                End If

                Return _sectionF
            End Get
        End Property

        Protected _sectionG As XElement = Nothing
        Protected ReadOnly Property SECTION_G() As XElement
            Get
                If _sectionG Is Nothing Then

                    Dim sectionG As XElement = oXML.Element(GFESection).Element("SECTION_G")
                    If sectionG Is Nothing Then
                        sectionG = <SECTION_G/>
                        SECTION_F.AddAfterSelf(sectionG)
                    End If

                    If sectionG.Elements("INITIAL_ESCROW_ITEM").Count = 0 Then
                        For counter As Integer = 1 To 3
                            sectionG.Add(<INITIAL_ESCROW_ITEM/>)
                        Next
                    End If

                    _sectionG = sectionG
                End If

                Return _sectionG
            End Get
        End Property


        Protected _InitialEscrow As List(Of XElement) = Nothing
        Protected ReadOnly Property InitialEscrow() As List(Of XElement)
            Get
                If _InitialEscrow Is Nothing Then
					_InitialEscrow = (From x In SECTION_G.Elements("INITIAL_ESCROW_ITEM") Where
										SafeDouble(GetAttribute(x, "initial_escrow_amount")) > 0 Select x).ToList
                    SortList(_InitialEscrow, "initial_escrow_description", "")
                End If
                Return _InitialEscrow
            End Get
        End Property

        Protected _sectionH As XElement = Nothing
        Protected ReadOnly Property SECTION_H() As XElement
            Get
                If _sectionH Is Nothing Then

                    Dim sectionH As XElement = oXML.Element(GFESection).Element("SECTION_H")
                    If sectionH Is Nothing Then
                        sectionH = <SECTION_H/>
                        SECTION_G.AddAfterSelf(sectionH)
                    End If

                    If sectionH.Elements("OTHER_ITEM").Count = 0 Then
                        For counter As Integer = 1 To 8
                            sectionH.Add(<OTHER_ITEM/>)
                        Next
                    End If

                    _sectionH = sectionH
                End If

                Return _sectionH
            End Get
        End Property

        Protected _OtherFees As List(Of XElement) = Nothing
        Protected ReadOnly Property OtherFees() As List(Of XElement)
            Get
                If _OtherFees Is Nothing Then
					_OtherFees = (From x In SECTION_H.Elements("OTHER_ITEM") Where
										SafeDouble(GetAttribute(x, "other_fee_amount")) > 0 Select x).ToList
                    SortList(_OtherFees, "other_fee_description", "FeeName")
                End If
                Return _OtherFees
            End Get
        End Property

        Protected _sectionI As XElement = Nothing
        Protected ReadOnly Property SECTION_I() As XElement
            Get
                If _sectionI Is Nothing Then

                    Dim sectionI As XElement = oXML.Element(GFESection).Element("SECTION_I")
                    If sectionI Is Nothing Then
                        sectionI = <SECTION_I/>
                        SECTION_H.AddAfterSelf(sectionI)
                    End If

                    _sectionI = sectionI
                End If

                Return _sectionI
            End Get
        End Property

        Protected _sectionJ As XElement = Nothing
        Protected ReadOnly Property SECTION_J() As XElement
            Get
                If _sectionJ Is Nothing Then

                    Dim sectionJ As XElement = oXML.Element(GFESection).Element("SECTION_J")
                    If sectionJ Is Nothing Then
                        sectionJ = <SECTION_J/>
                        SECTION_I.AddAfterSelf(sectionJ)
                    End If

                    _sectionJ = sectionJ
                End If

                Return _sectionJ
            End Get
        End Property

        Private Class xElementComparer
            Implements IComparer(Of XElement)

            Private sJSONKey As String = ""
            Private sAttributeKey As String = ""

            Public Sub New(ByVal psAttribute As String, Optional ByVal psJSONKey As String = "")
                sAttributeKey = psAttribute
                sJSONKey = psJSONKey
            End Sub

            Public Function Compare(ByVal x As XElement, ByVal y As XElement) As Integer Implements IComparer(Of XElement).Compare
                Dim sValx As String = ""
                Dim sValy As String = ""

                Dim js As New System.Web.Script.Serialization.JavaScriptSerializer

                If x IsNot Nothing AndAlso x.Attribute(sAttributeKey) IsNot Nothing Then
                    sValx = x.Attribute(sAttributeKey).Value
                    If sJSONKey <> "" Then
                        Dim oDict As Dictionary(Of String, String) = js.Deserialize(Of Dictionary(Of String, String))(sValx)

                        If oDict IsNot Nothing AndAlso oDict.ContainsKey(sJSONKey) Then
                            sValx = oDict(sJSONKey)
                        End If
                    End If
                End If

                If y IsNot Nothing AndAlso y.Attribute(sAttributeKey) IsNot Nothing Then
                    sValy = y.Attribute(sAttributeKey).Value
                    If sJSONKey <> "" Then
                        Dim oDict As Dictionary(Of String, String) = js.Deserialize(Of Dictionary(Of String, String))(sValy)

                        If oDict IsNot Nothing AndAlso oDict.ContainsKey(sJSONKey) Then
                            sValy = oDict(sJSONKey)
                        End If
                    End If
                End If

                Return sValx.CompareTo(sValy)
            End Function
        End Class

        Protected Sub SortList(ByRef poList As List(Of XElement), ByVal psDescription As String, ByVal psKey As String)
            Dim oElementsToRemove As New List(Of XElement)

            For Each oElement As XElement In poList
                If GetAttribute(oElement, psDescription) = "" Then
                    oElementsToRemove.Add(oElement)
                End If
            Next

            For Each oElement In oElementsToRemove
                poList.Remove(oElement)
            Next

            poList.Sort(New xElementComparer(psDescription, psKey))
        End Sub

        Protected Function GetValue(ByVal psJSON As String, ByVal psKey As String) As String
            Dim js As New System.Web.Script.Serialization.JavaScriptSerializer

            Dim oDict As Dictionary(Of String, String) = js.Deserialize(Of Dictionary(Of String, String))(psJSON)

            If oDict IsNot Nothing AndAlso oDict.ContainsKey(psKey) Then
                Return oDict(psKey)
            Else
                Return ""
            End If
        End Function

        Protected Function getContactName(ByVal pContactID As Guid) As String
            Dim contact As LoansPQBO.MortgageLoans.CMortgageContact = App.ToMortgageApp.Contacts.FindById(pContactID)
            If contact IsNot Nothing Then
                Return contact.CompanyName
            Else
                Return ""
            End If
        End Function

        Protected Function GetAttribute(ByVal pNode As XElement, ByVal pName As String) As String
            If pNode Is Nothing Then
                Return String.Empty
            End If

            If pNode.Attribute(pName) Is Nothing Then
                Return String.Empty
            End If

            Return SafeString(pNode.Attribute(pName).Value)
        End Function


        Function FormatCurrencyIfGreaterZero(ByVal pNumber As Double) As String
            If pNumber > 0 Then
                Return FormatCurrency(pNumber)
            End If

            Return ""
        End Function

        Function FormatNumberIfGreaterZero(ByVal pNumber As Double) As String
            If pNumber > 0 Then
                Return FormatNumber(pNumber)
            End If

            Return ""
        End Function
#End Region

#Region "GFEFunction"

        Public Function getDateIssued() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "date_issued")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "date_issued")
            End If

            Return sRet
        End Function

        Public Function getSettlementAgent() As String
            Return getContactName(SafeGUID(GetAttribute(oXML, "settlement_agent")))
        End Function

        Public Function getFileNumber() As String
            Return GetAttribute(oXML, "file_number")
        End Function

        Public Function getLoanTerm() As String
            Return GetAttribute(oXML, "tila_term")
        End Function

        Public Function getBalloonPaymentYear() As String
            Return GetAttribute(oXML.Element(GFESection), "balloon_payment_year")
        End Function

        Public Function getBalloonPaymentAmount() As String
            Return FormatNumber(safedouble(GetAttribute(oXML.Element(GFESection), "balloon_payment")), 2)
        End Function

        Public Function getTilaPurpose() As String
            Dim sRet As String = ""

            If GetAttribute(oXML, "tila_purpose") = "HE" Then
                sRet = "Home Equity Loan"
            ElseIf GetAttribute(oXML, "tila_purpose") = "P" Then
                sRet = "Purchase"
            ElseIf GetAttribute(oXML, "tila_purpose") = "R" Then
                sRet = "Refinance"
            End If

            If sRet = "" Then
                sRet = GetAttribute(oXML, "tila_purpose")
            End If

            Return sRet
        End Function

        Public Function getMICNumber() As String
            Return GetAttribute(oXML, "mic_number")
        End Function

        Public Function getCanTotalLoanAmountIncreaseAfterClosing() As Boolean
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "can_total_loan_amount_increase_after_closing")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "can_total_loan_amount_increase_after_closing")
            End If

            Return YNStringToBool(sRet)
        End Function

        Public Function getCanRateIncreaseAfterClosing() As Boolean
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "can_rate_increase_after_closing")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "can_rate_increase_after_closing")
            End If

            Return YNStringToBool(sRet)
        End Function

        Public Function getCanRateIncreaseAfterClosingMaxRate() As String
            Return GetAttribute(oXML.Element(GFESection), "max_rate_increase_percent")
        End Function

        Public Function getCanRateIncreaseAfterClosingMaxYear() As String
            Return GetAttribute(oXML.Element(GFESection), "rate_end_year")
        End Function

        Public Function getCanMonthlyPaymentIncreaseAfterClosingMaxPayment() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection), "max_monthly_payment_amount")), 0)
        End Function

        Public Function getCanMonthlyPaymentIncreaseAfterClosingMaxYear() As String
            Return GetAttribute(oXML.Element(GFESection), "monthly_payment_end_year")
        End Function

        Public Function getCanMonthlyPaymentIncreaseAfterClosing() As Boolean
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "can_monthly_payment_increase_after_closing")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "can_monthly_payment_increase_after_closing")
            End If

            Return YNStringToBool(sRet)
        End Function

        Public Function getMaxLoanAmount() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "max_loan_amount")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "max_loan_amount")
            End If

            Return sRet
        End Function

        Public Function getMaxYear() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "max_year")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "max_year")
            End If

            Return sRet
        End Function

        Public Function getRateStartYear() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "rate_start_year")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "rate_start_year")
            End If

            Return sRet
        End Function

        Public Function getMaxRateIncreasePercent() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "max_rate_increase_percent")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "max_rate_increase_percent")
            End If

            Return sRet
        End Function

        Public Function getRateEndYear() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "rate_end_year")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "rate_end_year")
            End If

            Return sRet
        End Function

        Public Function getMonthlyPaymentStartYear() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "monthly_payment_start_year")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "monthly_payment_start_year")
            End If

            Return sRet
        End Function

        Public Function getMaxMonthlyPaymentAmount() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "max_monthly_payment_amount")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "max_monthly_payment_amount")
            End If

            Return sRet
        End Function

        Public Function getMonthlyPaymentEndYear() As String
            Dim sRet As String = ""
            sRet = GetAttribute(oXML.Element(GFESection), "monthly_payment_end_year")

            If sRet = "" Then
                sRet = GetAttribute(oXML, "monthly_payment_end_year")
            End If

            Return sRet
        End Function

        Public Function getMonthlyPrincipalandInterest() As String
            Return formatnumber(safedouble(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_1")), 2)
        End Function

        Public Function getPaymentCalculationYearEnd1() As String
            Return GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "payment_calc_year_end1")
        End Function

        Public Function getEstimatedEscrow1() As String
            Dim sRet As String = ""
            If safedouble(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_escrow1")) = 0 Then
                sRet = "0"
            Else
                sRet = FormatCurrencyIfGreaterZero(safedouble(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_escrow1")))
            End If

            Return sRet
        End Function

        Public Function getEstimatedTotalMonthlyPayment1() As String
            Return formatnumber(safedouble(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment1")), 2)
        End Function

        Public Function getMonthlyPrincipalandInterestMin1() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_min2")), 0)
        End Function

        Public Function getMonthlyPrincipalandInterestMax1() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_max2")), 0)
        End Function

        Public Function getEstimatedTotalMonthlyPaymentMin1() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment_min2")), 0)
        End Function

        Public Function getEstimatedTotalMonthlyPaymentMax1() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment_max2")), 0)
        End Function

        Public Function getMonthlyPrincipalandInterestMin2() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_min3")), 0)
        End Function

        Public Function getMonthlyPrincipalandInterestMax2() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_max3")), 0)
        End Function

        Public Function getEstimatedTotalMonthlyPaymentMin2() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment_min3")), 0)
        End Function

        Public Function getEstimatedTotalMonthlyPaymentMax2() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment_max3")), 0)
        End Function

        Public Function getMonthlyPrincipalandInterestMin3() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_min4")), 0)
        End Function

        Public Function getMonthlyPrincipalandInterestMax3() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "principle_interest_max4")), 0)
        End Function

        Public Function getEstimatedTotalMonthlyPaymentMin3() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment_min4")), 0)
        End Function

        Public Function getEstimatedTotalMonthlyPaymentMax3() As String
            Return FormatNumber(SafeInteger(GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "estimated_total_monthly_payment_max4")), 0)
        End Function

        Public Function getPaymentCalculationYearEnd4() As String
            Return GetAttribute(oXML.Element(GFESection).Element("PROJECTED_PAYMENTS"), "payment_calc_year_end4")
        End Function

        Public Function getEstimatedTaxes() As String
            Return formatnumber(safedouble(GetAttribute(oXML, "estimated_ti")), 2)
        End Function

        Public Function getEstimatedTaxesPropertyTax() As String
            Dim sRet As String = ""
            If YNStringToBool(GetAttribute(oXML, "estimate_includes_property_taxes")) Then
                sRet = "X"
            End If

            Return sRet
        End Function

        Public Function getEstimatedTaxesPropertyTaxYesNo() As String
            Dim sRet As String = ""
            If GetAttribute(oXML, "property_taxes_in_escrow") = "Y" Then
                sRet = "YES"
            ElseIf GetAttribute(oXML, "property_taxes_in_escrow") = "N" Then
                sRet = "NO"
            End If

            Return sRet
        End Function

        Public Function getEstimatedTaxesHomeownerInsurance() As String
            Dim sRet As String = ""
            If YNStringToBool(GetAttribute(oXML, "estimate_includes_homeowners_insurance")) Then
                sRet = "X"
            End If

            Return sRet
        End Function

        Public Function getEstimatedTaxesHomeownerInsuranceYesNo() As String
            Dim sRet As String = ""
            If GetAttribute(oXML, "homeowners_insurance_in_escrow") = "S" Then
                sRet = "SOME"
            ElseIf GetAttribute(oXML, "homeowners_insurance_in_escrow") = "Y" Then
                sRet = "YES"
            ElseIf GetAttribute(oXML, "homeowners_insurance_in_escrow") = "N" Then
                sRet = "NO"
            End If

            Return sRet
        End Function

        Public Function getEstimatedTaxesOther() As String
            Dim sRet As String = ""
            If YNStringToBool(GetAttribute(oXML, "estimate_includes_other")) andalso
                        GetAttribute(oXML, "estimate_other_description") <> "" Then
                sRet = "X"
            End If

            Return sRet
        End Function

        Public Function getEstimateOtherDescription() As String
            Dim sRet As String = ""
            If YNStringToBool(GetAttribute(oXML, "estimate_includes_other")) andalso
                        GetAttribute(oXML, "estimate_other_description") <> "" Then
                sRet = GetAttribute(oXML, "estimate_other_description")
            End If

            Return sRet
        End Function

        Public Function getEstimateOtherYesNo() As String
            Dim sRet As String = ""
            If YNStringToBool(GetAttribute(oXML, "estimate_includes_other")) andalso
                        GetAttribute(oXML, "estimate_other_description") <> "" andalso
                        GetAttribute(oXML, "other_in_escrow") = "Y" Then
                sRet = "YES"
                    ElseIf YNStringToBool(GetAttribute(oXML, "estimate_includes_other")) andalso
                        GetAttribute(oXML, "estimate_other_description") <> "" andalso
                        GetAttribute(oXML, "other_in_escrow") = "N" Then
                sRet = "NO"
                    ElseIf YNStringToBool(GetAttribute(oXML, "estimate_includes_other")) andalso
                        GetAttribute(oXML, "estimate_other_description") <> "" andalso
                        GetAttribute(oXML, "other_in_escrow") = "S" Then
                sRet = "SOME"
            End If

            Return sRet
        End Function

        Public Function getClosingCosts() As String
            Dim sRet As String = ""
            If safedouble(GetAttribute(SECTION_J, "total_closing_costs_amount")) = 0 Then
                sRet = "0"
            Else
                sRet = FormatNumber(safedouble(GetAttribute(SECTION_J, "total_closing_costs_amount")), 2)
            End If

            Return sRet
        End Function

        Public Function getTotalLoanCosts() As String
            Return FormatNumber(safedouble(GetAttribute(SECTION_D, "total_loan_costs")), 2)
        End Function

        Public Function getTotalOtherCosts() As String
            Return FormatNumber(safedouble(GetAttribute(SECTION_I, "total_other_costs")), 2)
        End Function

        Public Function getLenderCredits() As String
            Return FormatNumber(safedouble(GetAttribute(SECTION_I, "lender_credits")), 2).TrimStart("-"c)
        End Function

        Public Function getCashToClose() As String
            Dim sRet As String = ""
            If safedouble(GetAttribute(oXML.Element(GFESection).Element("CASH_TO_CLOSE"), "alt_cash_to_close_amount")) = 0 Then
                sRet = "0"
            Else
                sRet = FormatNumber(safedouble(GetAttribute(oXML.Element(GFESection).Element("CASH_TO_CLOSE"), "alt_cash_to_close_amount")), 2).TrimStart("-"c)
            End If

            Return sRet
        End Function

        Public Function getCashToCloseFromBorrower() As String
            Dim sRet As String = ""
            If GetAttribute(oXML.Element(GFESection).Element("CASH_TO_CLOSE"), "alt_cash_to_close_target") = "FB" Then
                sRet = "X"
            End If

            Return sRet
        End Function

        Public Function getCashToCloseToBorrower() As String
            Dim sRet As String = ""
            If GetAttribute(oXML.Element(GFESection).Element("CASH_TO_CLOSE"), "alt_cash_to_close_target") = "TB" Then
                sRet = "X"
            End If

            Return sRet
        End Function

        Public Function getOrginationCharges() As String
            Return FormatNumberIfGreaterZero(safedouble(GetAttribute(SECTION_A, "origination_charge_subtotal")))
        End Function

        Public Function getLoanPoints() As String
            Dim sRet As String = ""
            If safedouble(Right(FormatNumber(safedouble(GetAttribute(SECTION_A, "loan_point")), 3), 1)) > 0 Then
                sRet = FormatNumber(safedouble(GetAttribute(SECTION_A, "loan_point")), 3)
            ElseIf safedouble(Right(FormatNumber(safedouble(GetAttribute(SECTION_A, "loan_point")), 3), 3)) > 0 Then
                sRet = FormatNumber(safedouble(GetAttribute(SECTION_A, "loan_point")), 2)
            ElseIf GetAttribute(SECTION_A, "loan_point") <> "" Then
                sRet = FormatNumber(safedouble(GetAttribute(SECTION_A, "loan_point")), 0)
            End If

            Return sRet
        End Function

        Public Function getPrepaidInterestDateFrom() As String
            Dim sRet As String = ""
            If safedouble(GetAttribute(SECTION_F, "prepaid_interest_amount")) > 0 Then
                sRet = GetAttribute(SECTION_F, "prepaid_interest_start_date")
            End If

            Return sRet
        End Function

        Public Function getPrepaidInterestDateTo() As String
            Dim sRet As String = ""
            If safedouble(GetAttribute(SECTION_F, "prepaid_interest_amount")) > 0 Then
                sRet = GetAttribute(SECTION_F, "prepaid_interest_end_date")
            End If

            Return sRet
        End Function

        Public Function getLimitsOnInterestRateChangesFirstChange() As String
            Dim sRet As String = ""
            If safedouble(right(FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateFirstPeriodCap), 3), 1)) > 0 Then
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateFirstPeriodCap), 3)
            ElseIf safedouble(right(FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateFirstPeriodCap), 3), 3)) > 0 Then
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateFirstPeriodCap), 2)
            Else
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateFirstPeriodCap), 0)
            End If

            Return sRet
        End Function

        Public Function getLimitsOnInterestRateChangesSubsequentChanges() As String
            Dim sRet As String = ""
            If safedouble(right(FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateSubsequentPeriodicCap), 3), 1)) > 0 Then
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateSubsequentPeriodicCap), 3)
            ElseIf safedouble(right(FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateSubsequentPeriodicCap), 3), 3)) > 0 Then
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateSubsequentPeriodicCap), 2)
            Else
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.LoanProductInfo.ARMRateSubsequentPeriodicCap), 0)
            End If

            Return sRet
        End Function

        Public Function getTotalInterestPercentageCD() As String
            Dim sRet As String = ""
            If safedouble(right(FormatNumber(safedouble(App.ToMortgageApp.AppInfo.TotalInterestPercentCD), 3), 1)) > 0 Then
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.TotalInterestPercentCD), 3)
            ElseIf safedouble(right(FormatNumber(safedouble(App.ToMortgageApp.AppInfo.TotalInterestPercentCD), 3), 3)) > 0 Then
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.TotalInterestPercentCD), 2)
            Else
                sRet = FormatNumber(safedouble(App.ToMortgageApp.AppInfo.TotalInterestPercentCD), 0)
            End If

            Return sRet
        End Function

#End Region

		Public Property GFESection As String = "CLOSING_DISCLOSURE"

		Public Overrides Function MapField(ByVal pName As String, ByRef pValue As String) As Boolean
            'Select Case pName
            '	Case "test"
            '	Case Else
            '		Return False
            'End Select
            'Return True
            Return False
        End Function
    End Class

End Namespace
